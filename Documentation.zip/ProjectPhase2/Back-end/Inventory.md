//psuedo code
/*
tracking inventory control---

use imports for connecting database

create variables for items?
for ex:
int iPhone13;
int (brand)laptop;

    if (this item is bought on external site)
    {
        item--;
    }

    if (order is cancelled)
    {
        item++;
    }

    if (this item is returned on external site)
    {
        item++;
    }

    if (item is scanned into warehouse?)
    {
        item++
    }
*/