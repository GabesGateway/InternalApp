/*

login----

create a string array for names of our employees and passwords
potentially employee pins if easier, something to where they can clock in with
Also to sign into internal site.

//the username will be listed in this string array
    String[] employees = [name, name, name];

    make variable for inputing a password
    String passwordInput = scnr.nextLine;
    
    make variable for employee passwords
    String[] employeePassword = [passwords for each employee]

    if (passwordInput != employeePassword)
    {
        System.out.println("Password is incoreect, try again.");
    }
    else
    {
        let employee into internal site
    }


*/